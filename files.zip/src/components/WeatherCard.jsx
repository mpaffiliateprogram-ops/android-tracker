import React from "react";

function WeatherCard({ weather }) {
  return (
    <div style={{ border: "1px solid #ccc", padding: "1em", marginTop: "1em" }}>
      <h2>{weather.name}</h2>
      <p>
        <strong>Temperature:</strong> {weather.main.temp}°C
      </p>
      <p>
        <strong>Condition:</strong> {weather.weather[0].description}
      </p>
      <p>
        <strong>Humidity:</strong> {weather.main.humidity}%
      </p>
      <p>
        <strong>Wind:</strong> {weather.wind.speed} m/s
      </p>
    </div>
  );
}

export default WeatherCard;