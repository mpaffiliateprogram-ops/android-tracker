import React, { useState } from "react";
import SearchBar from "./SearchBar";
import WeatherCard from "./WeatherCard";

const API_KEY = "YOUR_OPENWEATHERMAP_API_KEY"; // Replace with your API key

function WeatherDashboard() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState("");

  const fetchWeather = async (location) => {
    setError("");
    setWeather(null);
    try {
      const res = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${API_KEY}&units=metric`
      );
      if (!res.ok) {
        throw new Error("City not found");
      }
      const data = await res.json();
      setWeather(data);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <SearchBar onSearch={fetchWeather} />
      {error && <div style={{ color: "red" }}>{error}</div>}
      {weather && <WeatherCard weather={weather} />}
    </div>
  );
}

export default WeatherDashboard;