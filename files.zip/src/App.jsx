import React, { useState } from "react";
import WeatherDashboard from "./components/WeatherDashboard";

function App() {
  return (
    <div>
      <h1>Weather Dashboard</h1>
      <WeatherDashboard />
    </div>
  );
}

export default App;